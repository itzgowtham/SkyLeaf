package com.jspiders.skyleaf.repository;

import org.springframework.data.repository.CrudRepository;

import com.jspiders.skyleaf.beans.PaymentMethod;

public interface PaymentMethodRepository extends CrudRepository<PaymentMethod, String>{

}
